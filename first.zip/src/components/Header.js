import React from 'react';
import {Link} from 'react-router-dom';

const Header = ()=>{
    return (
        <header>
            <h1>Book Management App</h1>
            
            <div className="links">
                <Link to="/" className="link"  >
                    Book List
                 </Link>   
                 <Link to="/add" className="link" >
                     add Book
                    </Link>
            </div>
        </header>
    );
};
export default Header;